#ifndef __MOTOR_H
#define __MOTOR_H
/*
1.���ļ�����Ҫ���κθ���
*/
void Motor_Init(void);
void LeftWheelFront_Speed(int Speed);
void LeftWheelBehind_Speed(int Speed);
void RightWheelFront_Speed(int Speed);
void RightWheelBehind_Speed(int Speed);
void Advance(void);



#endif
